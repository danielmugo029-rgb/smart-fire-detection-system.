"""Validated configuration for the Smart Fire Detection prototype."""
from dataclasses import dataclass
import os

@dataclass(frozen=True)
class Settings:
    camera_source: str = os.getenv("CAMERA_SOURCE", "0")
    model_id: str = os.getenv("ROBOFLOW_MODEL_ID", "")
    api_url: str = os.getenv("ROBOFLOW_API_URL", "https://detect.roboflow.com")
    api_key: str = os.getenv("ROBOFLOW_API_KEY", "")
    confidence: float = float(os.getenv("CONFIDENCE_THRESHOLD", "0.55"))
    persistence_frames: int = int(os.getenv("PERSISTENCE_FRAMES", "3"))
    cooldown_seconds: int = int(os.getenv("ALERT_COOLDOWN_SECONDS", "60"))
    camera_name: str = os.getenv("CAMERA_NAME", "Camera 1")
    site_name: str = os.getenv("SITE_NAME", "Unspecified site")
    database_path: str = os.getenv("DATABASE_PATH", "fire_events.sqlite3")
    snapshot_dir: str = os.getenv("SNAPSHOT_DIR", "evidence/snapshots")
    alarm_enabled: bool = os.getenv("ALARM_ENABLED", "true").lower() == "true"
    twilio_sid: str = os.getenv("TWILIO_ACCOUNT_SID", "")
    twilio_token: str = os.getenv("TWILIO_AUTH_TOKEN", "")
    twilio_from: str = os.getenv("TWILIO_FROM_NUMBER", "")
    alert_to: str = os.getenv("ALERT_TO_NUMBER", "")

    def validate(self):
        if not 0.0 < self.confidence <= 1.0:
            raise ValueError("CONFIDENCE_THRESHOLD must be > 0 and <= 1")
        if self.persistence_frames < 1:
            raise ValueError("PERSISTENCE_FRAMES must be at least 1")
        if self.cooldown_seconds < 0:
            raise ValueError("ALERT_COOLDOWN_SECONDS cannot be negative")
        return self
