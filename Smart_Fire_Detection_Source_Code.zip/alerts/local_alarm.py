"""Best-effort local audible warning. Hardware certification is outside this prototype."""
import sys, time
class LocalAlarm:
    def trigger(self):
        try:
            if sys.platform.startswith("win"):
                import winsound
                winsound.MessageBeep(winsound.MB_ICONEXCLAMATION)
            else:
                print("\\a", end="", flush=True)
            return "triggered"
        except Exception as exc:
            return f"unavailable: {exc}"
