"""Optional Twilio SMS integration; records attempts, never assumes delivery."""
class SmsNotifier:
    def __init__(self, sid, token, from_number, to_number):
        self.config=(sid,token,from_number,to_number)
    def send(self, body):
        sid,token,from_no,to_no=self.config
        if not all(self.config):
            return "not_configured"
        try:
            from twilio.rest import Client
            message=Client(sid,token).messages.create(body=body,from_=from_no,to=to_no)
            return f"provider_accepted:{message.sid}"
        except Exception as exc:
            return f"failed:{type(exc).__name__}:{exc}"
