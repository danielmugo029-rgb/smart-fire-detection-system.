"""Roboflow Inference SDK adapter. No prediction is fabricated on failure."""
class RoboflowDetector:
    def __init__(self, api_url, api_key, model_id):
        if not model_id:
            raise ValueError("Set ROBOFLOW_MODEL_ID to a deployed model identifier")
        try:
            from inference_sdk import InferenceHTTPClient
        except ImportError as exc:
            raise RuntimeError("Install inference-sdk to enable model inference") from exc
        kwargs = {"api_url": api_url}
        if api_key:
            kwargs["api_key"] = api_key
        self.client = InferenceHTTPClient(**kwargs)
        self.model_id = model_id

    def predict(self, frame):
        result = self.client.infer(frame, model_id=self.model_id)
        predictions = result.get("predictions", []) if isinstance(result, dict) else []
        normalized=[]
        for p in predictions:
            try:
                normalized.append({
                    "label": str(p.get("class", p.get("class_name", "unknown"))).lower(),
                    "confidence": float(p.get("confidence", 0.0)),
                    "x": float(p.get("x", 0)), "y": float(p.get("y", 0)),
                    "width": float(p.get("width", 0)), "height": float(p.get("height", 0))
                })
            except (TypeError, ValueError):
                continue
        return normalized
