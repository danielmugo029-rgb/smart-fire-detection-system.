"""Temporal decision rule to reduce one-frame alerts."""
class FireDecision:
    FIRE_LABELS = {"fire", "flame", "smoke"}
    def __init__(self, threshold=0.55, persistence_frames=3):
        self.threshold=float(threshold); self.persistence_frames=int(persistence_frames)
        self.streak=0; self.last_match=None
    def update(self, predictions):
        matches=[p for p in predictions if p.get("label", "").lower() in self.FIRE_LABELS and float(p.get("confidence",0)) >= self.threshold]
        if matches:
            self.streak += 1
            self.last_match=max(matches,key=lambda p:float(p.get("confidence",0)))
        else:
            self.streak=0; self.last_match=None
        return self.streak >= self.persistence_frames, self.last_match
