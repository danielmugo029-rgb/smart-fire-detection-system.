# Smart Fire Detection and Alarm System

## Purpose
A supplementary visual warning prototype. It is not certified fire-safety equipment and must not replace smoke/heat alarms, evacuation plans or emergency services.

## Requirements
Python 3.10+, webcam or video source, internet access for hosted inference, a deployed Roboflow-compatible model, and optional Twilio credentials for SMS.

## Setup
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```
Edit `.env` locally. Set `ROBOFLOW_MODEL_ID` to the exact deployed model identifier and keep credentials private. Use a test video first:
```bash
python app.py --source path/to/test_video.mp4
```
For a webcam use `--source 0`. Press `q` to stop the preview. Use `--no-display` for headless runs.

## Tests
```bash
pytest -q
```
The included unit tests validate the temporal decision rule only. They do not establish fire-model accuracy, camera integration, SMS delivery or hardware alarm performance.

## Safety and deployment
Use only approved test footage or supervised safe test procedures. Do not create an uncontrolled fire. Do not configure public emergency numbers without written approval and a verified response protocol. SMS status `provider_accepted` means the provider accepted the request, not that a person received or acted on it. Review camera permissions, retention, access controls and applicable Kenyan data-protection obligations before deployment.
