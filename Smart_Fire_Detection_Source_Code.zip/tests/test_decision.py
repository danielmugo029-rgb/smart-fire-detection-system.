from detection.decision import FireDecision

def test_requires_persistent_detection():
    d=FireDecision(.5,3)
    p=[{"label":"fire","confidence":.9}]
    assert d.update(p)[0] is False
    assert d.update(p)[0] is False
    assert d.update(p)[0] is True

def test_below_threshold_does_not_trigger():
    d=FireDecision(.7,2)
    assert d.update([{"label":"fire","confidence":.4}])[0] is False

def test_non_fire_label_resets_streak():
    d=FireDecision(.5,2)
    d.update([{"label":"fire","confidence":.9}])
    assert d.update([{"label":"person","confidence":.99}])[0] is False
    assert d.update([{"label":"fire","confidence":.9}])[0] is False
