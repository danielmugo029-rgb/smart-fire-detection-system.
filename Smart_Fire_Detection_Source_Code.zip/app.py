"""Smart Fire Detection and Alarm System: camera -> model -> decision -> alert/log."""
import argparse, os, time, logging
from datetime import datetime
import cv2
from dotenv import load_dotenv
load_dotenv()
from config import Settings
from detection.inference import RoboflowDetector
from detection.decision import FireDecision
from storage.database import EventStore
from alerts.local_alarm import LocalAlarm
from alerts.notifications import SmsNotifier

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

def parse_source(value):
    return int(value) if value.isdigit() else value

def main():
    parser=argparse.ArgumentParser(description="Supplementary AI visual fire warning prototype")
    parser.add_argument("--source", help="Camera index or video/RTSP source; overrides CAMERA_SOURCE")
    parser.add_argument("--no-display", action="store_true", help="Run without preview window")
    args=parser.parse_args()
    cfg=Settings().validate()
    source=parse_source(args.source or cfg.camera_source)
    os.makedirs(cfg.snapshot_dir,exist_ok=True)
    store=EventStore(cfg.database_path)
    detector=RoboflowDetector(cfg.api_url,cfg.api_key,cfg.model_id)
    decision=FireDecision(cfg.confidence,cfg.persistence_frames)
    alarm=LocalAlarm()
    notifier=SmsNotifier(cfg.twilio_sid,cfg.twilio_token,cfg.twilio_from,cfg.alert_to)
    cap=cv2.VideoCapture(source)
    if not cap.isOpened():
        raise RuntimeError(f"Unable to open video source: {source}")
    last_alert=0.0
    logging.info("Monitoring started. Press q in preview window to stop.")
    try:
        while True:
            ok,frame=cap.read()
            if not ok:
                logging.warning("Video frame unavailable; stopping source loop")
                break
            try:
                predictions=detector.predict(frame)
            except Exception as exc:
                logging.error("Inference unavailable: %s",exc)
                if not args.no_display:
                    cv2.putText(frame,"MODEL CONNECTION ERROR",(20,35),cv2.FONT_HERSHEY_SIMPLEX,.7,(0,0,255),2)
                predictions=[]
            triggered,match=decision.update(predictions)
            for p in predictions:
                if p["label"] in FireDecision.FIRE_LABELS:
                    cv2.putText(frame,f'{p["label"]}: {p["confidence"]:.2f}',(20,65),cv2.FONT_HERSHEY_SIMPLEX,.6,(0,0,255),2)
            now=time.time()
            if triggered and match and now-last_alert >= cfg.cooldown_seconds:
                stamp=datetime.now().strftime("%Y%m%d_%H%M%S")
                snapshot=os.path.join(cfg.snapshot_dir,f"possible_fire_{stamp}.jpg")
                cv2.imwrite(snapshot,frame)
                alarm_status=alarm.trigger() if cfg.alarm_enabled else "disabled"
                body=(f"POSSIBLE FIRE DETECTED at {cfg.site_name}, {cfg.camera_name}. "
                      f"Time: {datetime.now().isoformat(timespec='seconds')}. "
                      f"Model confidence: {match['confidence']:.2f}. Follow the site emergency plan; do not approach the hazard.")
                notification_status=notifier.send(body)
                event_id=store.add_event(cfg.site_name,cfg.camera_name,match["label"],match["confidence"],snapshot,alarm_status,notification_status)
                logging.warning("Possible fire event %s recorded; SMS status=%s",event_id,notification_status)
                last_alert=now
            if not args.no_display:
                cv2.imshow("Smart Fire Detection | supplementary warning",frame)
                if cv2.waitKey(1)&0xFF==ord('q'):
                    break
    finally:
        cap.release()
        cv2.destroyAllWindows()
        logging.info("Monitoring stopped; camera resources released")

if __name__=="__main__":
    main()
