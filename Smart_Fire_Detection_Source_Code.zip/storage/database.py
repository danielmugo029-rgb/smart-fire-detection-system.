"""SQLite event and notification audit storage."""
import sqlite3
from datetime import datetime, timezone
class EventStore:
    def __init__(self, path):
        self.path=path; self._init()
    def connect(self):
        return sqlite3.connect(self.path)
    def _init(self):
        with self.connect() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL,
                site TEXT NOT NULL, camera TEXT NOT NULL, label TEXT NOT NULL,
                confidence REAL NOT NULL, snapshot_path TEXT, alarm_status TEXT,
                notification_status TEXT, notes TEXT)""")
    def add_event(self, site, camera, label, confidence, snapshot_path, alarm_status, notification_status, notes=""):
        stamp=datetime.now(timezone.utc).isoformat()
        with self.connect() as c:
            cur=c.execute("INSERT INTO events(created_at,site,camera,label,confidence,snapshot_path,alarm_status,notification_status,notes) VALUES(?,?,?,?,?,?,?,?,?)",
                (stamp,site,camera,label,confidence,snapshot_path,alarm_status,notification_status,notes))
            return cur.lastrowid
